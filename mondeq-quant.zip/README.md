# mondeq-quant

MONDEQ experiments with quantisation, spectral diagnostics, and solver callbacks.

## Quick start

CPU:
```bash
bash scripts/bootstrap_env.sh
